// offscreen.js

// Function to find the most prominent external link on LinkedIn's interstitial page
function findInterstitialTargetLink(doc, originalShortUrl) {
    if (!doc || !doc.body) {
        console.warn("Offscreen: Document or body is not available for parsing.");
        return null;
    }

    // Log the HTML for debugging if needed
    // console.log("Offscreen Interstitial HTML:", doc.body.innerHTML);

    // Attempt 1: Specific class for the main link on the "leaving LinkedIn" page
    // Example: <a href="..." class="safety-redirect-page__link">...</a>
    // Example from a real page: <a href="..." class="external-link-processor__safety-link">...</a>
    let targetLink = doc.querySelector('a.safety-redirect-page__link, a.external-link-processor__safety-link');
    if (targetLink && targetLink.href && !targetLink.href.startsWith('https://www.linkedin.com') && !targetLink.href.includes('lnkd.in')) {
        console.log("Offscreen: Found link by specific class:", targetLink.href);
        return targetLink.href;
    }

    // Attempt 2: Look for a link whose text content IS the URL and is not a linkedin.com URL
    // This is often how the "https://www.ixperium.nl/..." link is displayed.
    const anchors = doc.querySelectorAll('a[href]');
    for (const anchor of anchors) {
        const href = anchor.getAttribute('href'); // Get raw href
        const textContent = anchor.textContent.trim();

        if (href && textContent && (href === textContent || textContent.startsWith(href)) &&
            !href.startsWith('https://www.linkedin.com') &&
            !href.includes('lnkd.in') &&
            href !== originalShortUrl) {
            console.log("Offscreen: Found link where href matches textContent:", href);
            return href;
        }
    }

    // Attempt 3: Look for a prominent paragraph or div that ONLY contains a URL as text.
    // This is a fallback if the link isn't in a typical <a> tag with matching href/text.
    const urlRegex = /^(https?:\/\/[^\s"<>]+)$/; // Regex for a string that is only a URL
    const pTags = doc.querySelectorAll('p, div'); // Check common text containers
    for (const pTag of pTags) {
        const text = pTag.textContent.trim();
        if (urlRegex.test(text) && !text.includes('linkedin.com') && !text.includes('lnkd.in') && text !== originalShortUrl) {
            console.log("Offscreen: Found URL-like text in <p> or <div>:", text);
            return text;
        }
    }
    
    // Attempt 4: Check if the iframe's current location itself is the target,
    // but only if it's clearly not a LinkedIn domain.
    try {
        const iframeLocation = doc.defaultView.location.href;
        if (iframeLocation && !iframeLocation.includes('linkedin.com') && !iframeLocation.includes('lnkd.in') && iframeLocation !== originalShortUrl) {
             console.log("Offscreen: Using iframe's final location:", iframeLocation);
             return iframeLocation;
        }
    } catch(e) {
        console.warn("Offscreen: Could not access iframe.contentWindow.location.href directly during DOM parse.");
    }


    console.log("Offscreen: Could not find a clear external link in the iframe DOM for:", originalShortUrl);
    return null;
}


chrome.runtime.onMessage.addListener(async (msg, sender, sendResponse) => {
    if (msg.offscreen && msg.action === 'unshortenViaOffscreenDOM') {
        let iframe;
        try {
            iframe = document.createElement('iframe');
            iframe.style.display = 'none'; // Keep it hidden
            // Sandbox to prevent top-level navigation and some script execution if desired,
            // but it might break legitimate interstitial pages. Test carefully.
            // iframe.sandbox = 'allow-scripts allow-same-origin';

            const promise = new Promise(async (resolve) => {
                let resolvedUrl = msg.targetUrl; // Start with the URL given to the offscreen doc
                const originalShortUrl = msg.originalShortUrl; // Keep the original short URL for comparison

                const timeoutId = setTimeout(() => {
                    console.warn("Offscreen: Timeout for", originalShortUrl);
                    if (document.body.contains(iframe)) {
                        document.body.removeChild(iframe);
                    }
                    resolve(originalShortUrl); // Fallback to original short URL on timeout
                }, 12000); // Increased timeout to 12 seconds

                iframe.onload = async () => {
                    clearTimeout(timeoutId);
                    try {
                        // Give the interstitial page a moment for JS to potentially modify the DOM
                        await new Promise(r => setTimeout(r, 1000));

                        const currentIframeLocation = iframe.contentWindow.location.href;

                        if (currentIframeLocation &&
                            !currentIframeLocation.includes('lnkd.in') &&
                            !currentIframeLocation.includes('linkedin.com/authwall') &&
                            !currentIframeLocation.includes('linkedin.com/safety/go')) {
                            resolvedUrl = currentIframeLocation;
                            console.log("Offscreen: Resolved by iframe location directly:", resolvedUrl);
                        } else {
                            console.log("Offscreen: iframe location is still LinkedIn or lnkd.in for", originalShortUrl, ". Parsing DOM.");
                            const extractedLink = findInterstitialTargetLink(iframe.contentDocument, originalShortUrl);
                            if (extractedLink) {
                                resolvedUrl = extractedLink;
                            } else if (currentIframeLocation && currentIframeLocation !== originalShortUrl) {
                                // If DOM parsing failed but iframe location is different, use that (might be the interstitial itself)
                                resolvedUrl = currentIframeLocation;
                                console.log("Offscreen: DOM parse failed for", originalShortUrl, ", using iframe location:", resolvedUrl);
                            } else {
                                console.log("Offscreen: DOM parse and iframe location did not yield a better URL for", originalShortUrl);
                                resolvedUrl = originalShortUrl; // Fallback to original if no better found
                            }
                        }
                    } catch (e) {
                        console.warn("Offscreen: Error processing iframe for", originalShortUrl, ":", e.message);
                        resolvedUrl = originalShortUrl; // Fallback to original short URL
                    } finally {
                        if (document.body.contains(iframe)) {
                           document.body.removeChild(iframe);
                        }
                        resolve(resolvedUrl);
                    }
                };

                iframe.onerror = (err) => {
                    clearTimeout(timeoutId);
                    console.error("Offscreen: Iframe load error for unshortening:", originalShortUrl, err);
                    if (document.body.contains(iframe)) {
                        document.body.removeChild(iframe);
                    }
                    resolve(originalShortUrl); // Fallback to original short URL on error
                };

                console.log("Offscreen: Loading URL in iframe:", msg.targetUrl);
                iframe.src = msg.targetUrl; // Use the URL passed (could be already partially resolved by fetch)
                document.body.appendChild(iframe);
            });

            sendResponse(await promise);

        } catch (e) {
            console.error('Error in offscreen document during unshortenViaOffscreenDOM:', e);
            if (iframe && document.body.contains(iframe)) {
                document.body.removeChild(iframe);
            }
            sendResponse(msg.originalShortUrl || msg.targetUrl); // Fallback
        }
        return true;
    }
});