// background.js
const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';

async function hasOffscreenDocument(path) {
  const offscreenUrl = chrome.runtime.getURL(path);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl]
  });
  return contexts.length > 0;
}

async function ensureOffscreenDocument() {
  if (await hasOffscreenDocument(OFFSCREEN_DOCUMENT_PATH)) {
    return;
  }
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: [chrome.offscreen.Reason.DOM_PARSER],
    justification: 'To parse lnkd.in interstitial pages for the final URL.',
  });
}

async function resolveShortUrl(shortUrl) {
  let finalUrl = shortUrl;
  let attemptOffscreen = false;

  try {
    const response = await fetch(shortUrl, { method: 'HEAD', redirect: 'follow', cache: 'no-store' }); // Added no-store
    if (response && response.url && response.url !== shortUrl && !response.url.includes("linkedin.com/authwall")) {
      finalUrl = response.url;
    } else {
      const getResponse = await fetch(shortUrl, { method: 'GET', redirect: 'follow', cache: 'no-store' }); // Added no-store
      if (getResponse && getResponse.url && getResponse.url !== shortUrl && !getResponse.url.includes("linkedin.com/authwall")) {
        finalUrl = getResponse.url;
      }
    }

    // If it's an lnkd.in URL, OR if the resolved URL is a LinkedIn interstitial/safety page,
    // OR if the URL hasn't changed significantly (still lnkd.in), then try offscreen.
    if (shortUrl.includes('lnkd.in/') ||
        finalUrl.includes('linkedin.com/safety/go') ||
        finalUrl.includes('linkedin.com/authwall') ||
        finalUrl === shortUrl || // If fetch didn't change it at all
        (finalUrl.includes('lnkd.in') && finalUrl !== shortUrl) // If it resolved to another lnkd.in
       ) {
      attemptOffscreen = true;
    }

    if (attemptOffscreen) {
      console.log(`URL ${shortUrl} (resolved by fetch to ${finalUrl}) will be processed by offscreen document.`);
      await ensureOffscreenDocument();
      const originalUrlFromOffscreen = await chrome.runtime.sendMessage({
          action: 'unshortenViaOffscreenDOM',
          targetUrl: finalUrl, // Send the URL that fetch gave, or the original shortUrl
          originalShortUrl: shortUrl // Also send original to avoid re-matching it
      });
      // Only update if offscreen provides a *different* and valid-looking URL
      if (originalUrlFromOffscreen &&
          originalUrlFromOffscreen !== shortUrl &&
          originalUrlFromOffscreen !== finalUrl &&
          !originalUrlFromOffscreen.includes('linkedin.com')) {
        console.log("Offscreen resolved to:", originalUrlFromOffscreen);
        finalUrl = originalUrlFromOffscreen;
      } else {
        console.log("Offscreen did not provide a better URL or returned a LinkedIn URL. Using fetch result:", finalUrl);
      }
    }
    return finalUrl;

  } catch (error) {
    console.warn(`Error unshortening ${shortUrl} via fetch: ${error.message}. Trying offscreen as fallback.`);
    try {
        await ensureOffscreenDocument();
        const originalUrlFromOffscreen = await chrome.runtime.sendMessage({
            action: 'unshortenViaOffscreenDOM',
            targetUrl: shortUrl, // Fallback to original short URL for offscreen
            originalShortUrl: shortUrl
        });
        if (originalUrlFromOffscreen && originalUrlFromOffscreen !== shortUrl && !originalUrlFromOffscreen.includes('linkedin.com')) {
            return originalUrlFromOffscreen;
        }
     } catch (offscreenError) {
        console.error(`Offscreen unshortening also failed for ${shortUrl}: ${offscreenError.message}`);
     }
    return shortUrl; // Return original if all methods fail or don't improve
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "unshortenLinks" && request.linksMap) {
    const linkPromises = Object.entries(request.linksMap).map(async ([shortUrl, placeholder]) => {
      const originalUrl = await resolveShortUrl(shortUrl);
      return { placeholder, shortUrl, originalUrl };
    });

    Promise.all(linkPromises)
      .then(results => {
        sendResponse({ unshortenedLinks: results });
      })
      .catch(error => {
        console.error("Error during bulk unshortening:", error);
        sendResponse({ error: error.message, unshortenedLinks: [] });
      });
    return true;
  }

  if (request.action === "downloadImage" && request.imageUrl) {
    chrome.downloads.download({
      url: request.imageUrl,
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.error("Download failed:", chrome.runtime.lastError.message);
        sendResponse({ success: false, error: chrome.runtime.lastError.message });
      } else {
        if (downloadId !== undefined) { // Check if downloadId is defined
            sendResponse({ success: true, downloadId: downloadId });
        } else {
            console.error("Download did not start properly, downloadId is undefined.");
            sendResponse({ success: false, error: "Download could not be initiated (no ID)." });
        }
      }
    });
    return true;
  }
});