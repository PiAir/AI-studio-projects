// popup.js
const extractButton = document.getElementById('extractButton');
const postTitleInput = document.getElementById('postTitle');
const postBodyTextarea = document.getElementById('postBody');
const copyTitleButton = document.getElementById('copyTitleButton');
const copyBodyButton = document.getElementById('copyBodyButton');
const imageLinksDiv = document.getElementById('imageLinks');
const originalUrlsDiv = document.getElementById('originalUrls');
const copyResolvedLinksButton = document.getElementById('copyResolvedLinksButton'); // New button
const statusMessageDiv = document.getElementById('statusMessage');

// ... (setStatus function remains the same) ...
function setStatus(message, isError = false) {
  statusMessageDiv.textContent = message;
  statusMessageDiv.style.color = isError ? 'red' : '#555';
}


extractButton.addEventListener('click', async () => {
  setStatus("Extracting content...");
  postTitleInput.value = '';
  postBodyTextarea.value = '';
  imageLinksDiv.innerHTML = '<p class="status">Extracting images...</p>';
  originalUrlsDiv.innerHTML = '<p class="status">Looking for lnkd.in links...</p>';

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (tab && tab.url && (tab.url.includes("linkedin.com/posts/") || tab.url.includes("linkedin.com/feed/update/urn:li:activity:") || tab.url.includes("linkedin.com/feed/update/urn:li:share:"))) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content_script.js']
      });
    } catch (e) {
      setStatus(`Error injecting script: ${e.message}`, true);
      console.error("Injection error:", e);
    }
  } else {
    setStatus("Please navigate to a LinkedIn post page (e.g., linkedin.com/posts/... or feed/update/...).", true);
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "scrapedData") {
    setStatus("Content extracted. Processing links...");
    const { body, imageUrls, linksToUnshorten } = request.data;

    postTitleInput.value = body ? body.substring(0, 70).split('\n')[0].trim() + (body.length > 70 ? "..." : "") : "LinkedIn Post";
    let processedBody = body || "Could not extract body content."; // Use this for link replacement

    imageLinksDiv.innerHTML = '';
    if (imageUrls && imageUrls.length > 0) {
      imageUrls.forEach(url => {
        const div = document.createElement('div');
        const textSpan = document.createElement('span');
        textSpan.textContent = url + " ";
        div.appendChild(textSpan);

        const downloadButton = document.createElement('button');
        downloadButton.textContent = "Download";
        downloadButton.classList.add('secondary', 'download-image-btn');
        downloadButton.onclick = () => {
          const imageName = url.substring(url.lastIndexOf('/') + 1).split('?')[0] || "image.jpg";
          setStatus(`Downloading ${imageName}...`);
          chrome.runtime.sendMessage({ action: "downloadImage", imageUrl: url }, (response) => {
            if (chrome.runtime.lastError) { // Important: Check runtime.lastError for sendMessage
                setStatus(`Failed to initiate download for ${imageName}. ${chrome.runtime.lastError.message}`, true);
                return;
            }
            if (response && response.success) {
              setStatus(`Download started for ${imageName} (ID: ${response.downloadId}).`);
            } else {
              setStatus(`Failed to start download for ${imageName}. ${response.error || 'Unknown error.'}`, true);
            }
          });
        };
        div.appendChild(downloadButton);
        imageLinksDiv.appendChild(div);
      });
    } else {
      imageLinksDiv.innerHTML = '<p class="status">No direct image URLs found in the post content.</p>';
    }

    if (linksToUnshorten && Object.keys(linksToUnshorten).length > 0) {
      originalUrlsDiv.innerHTML = '<p class="status">Unshortening lnkd.in links...</p>';
      chrome.runtime.sendMessage({ action: "unshortenLinks", linksMap: linksToUnshorten }, (response) => {
        if (chrome.runtime.lastError) {
            setStatus(`Error unshortening links: ${chrome.runtime.lastError.message}`, true);
            originalUrlsDiv.innerHTML = '<p class="status">Error during link unshortening.</p>';
            postBodyTextarea.value = processedBody; // Set the body as is
            return;
        }

        if (response && response.unshortenedLinks) {
          originalUrlsDiv.innerHTML = '';
          let allResolvedLinksText = []; // For the new copy button

          response.unshortenedLinks.forEach(item => {
            const div = document.createElement('div');
            const shortLinkText = document.createTextNode(`${item.shortUrl}  ➔  `);
            div.appendChild(shortLinkText);

            const a = document.createElement('a');
            a.href = item.originalUrl;
            a.textContent = item.originalUrl;
            a.target = "_blank"; // Still allow opening in new tab
            div.appendChild(a);
            originalUrlsDiv.appendChild(div);
            allResolvedLinksText.push(`${item.shortUrl} -> ${item.originalUrl}`);


            // Replace placeholder with the original URL in our working copy of the body
            const placeholderRegex = new RegExp(item.placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
            processedBody = processedBody.replace(placeholderRegex, item.originalUrl);
          });

          // Attach data to the copy button
          copyResolvedLinksButton.dataset.resolvedLinks = allResolvedLinksText.join('\n');

          setStatus("Extraction and link processing complete.", false);
        } else if (response && response.error) {
            setStatus(`Error unshortening links: ${response.error}`, true);
            originalUrlsDiv.innerHTML = `<p class="status">Error: ${response.error}</p>`;
        } else {
            setStatus("Link unshortening finished; some links might not have resolved.", false);
             originalUrlsDiv.innerHTML = '<p class="status">Some links may not have resolved or an issue occurred.</p>';
        }
        postBodyTextarea.value = processedBody; // Set the final body text
      });
    } else {
      originalUrlsDiv.innerHTML = '<p class="status">No lnkd.in links found to unshorten.</p>';
      postBodyTextarea.value = processedBody;
      copyResolvedLinksButton.dataset.resolvedLinks = ""; // Clear if no links
      setStatus("Extraction complete. No lnkd.in links to process.", false);
    }
  }
});

// ... (copyTitleButton and copyBodyButton event listeners remain the same) ...
copyTitleButton.addEventListener('click', () => {
  postTitleInput.select();
  try {
    navigator.clipboard.writeText(postTitleInput.value)
      .then(() => setStatus("Title copied!", false))
      .catch(err => setStatus(`Failed to copy title: ${err.message}`, true));
  } catch (err) {
    try {
        document.execCommand('copy');
        setStatus("Title copied (fallback method)!", false);
    } catch (fallbackErr) {
        setStatus(`Failed to copy title (fallback): ${fallbackErr.message}`, true);
    }
  }
});

copyBodyButton.addEventListener('click', () => {
  postBodyTextarea.select();
   try {
    navigator.clipboard.writeText(postBodyTextarea.value)
      .then(() => setStatus("Body copied!", false))
      .catch(err => setStatus(`Failed to copy body: ${err.message}`, true));
  } catch (err) {
    try {
        document.execCommand('copy');
        setStatus("Body copied (fallback method)!", false);
    } catch (fallbackErr) {
        setStatus(`Failed to copy body (fallback): ${fallbackErr.message}`, true);
    }
  }
});

copyResolvedLinksButton.addEventListener('click', () => {
  const linksToCopy = copyResolvedLinksButton.dataset.resolvedLinks;
  if (linksToCopy) {
    try {
      navigator.clipboard.writeText(linksToCopy)
        .then(() => setStatus("Resolved links copied!", false))
        .catch(err => setStatus(`Failed to copy resolved links: ${err.message}`, true));
    } catch (err) {
        try {
            // Fallback for older browsers or restricted environments
            const textArea = document.createElement("textarea");
            textArea.value = linksToCopy;
            textArea.style.position = "fixed"; // Prevent scrolling to bottom
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            setStatus("Resolved links copied (fallback method)!", false);
        } catch (fallbackErr) {
             setStatus(`Failed to copy resolved links (fallback): ${fallbackErr.message}`, true);
        }
    }
  } else {
    setStatus("No resolved links to copy.", false);
  }
});